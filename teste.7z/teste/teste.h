#ifndef TESTE_H_INCLUDED
#define TESTE_H_INCLUDED

typedef struct{
    int numero;
}Registro;

typedef struct pagina *Apontador;

typedef struct pagina{
    int n;
    Registro reg[4];
    Apontador vet[4+1];
}Pagina;

void Insere_Dados(Apontador *pApont, int x){
    int cresceu;
    Registro retorno;
    Pagina *pRetorno, *pTemp;
    Aux_Insere();
    if (cresceu){
        pTemp = (Apontador)malloc(sizeof(Pagina));
        pTemp->n = 1;
        pTemp->reg[0] = retorno;
        pTemp->vet[1] = pRetorno;
        pTemp->vet[0] = pApont;
        pApont = pTemp;
    }
}

void Aux_Insere(int x, Apontador pApont, int *cresceu, Registro *retorno, Apontador *pRetorno){
    int i = 1,
        j;
    Apontador pTemp;

    if (pApont == NULL){
        *cresceu = TRUE;
        (*retorno) = x;
        (*pRetorno) = NULL;
        return;
    }
    while (i < pApont->n && x > pApont->reg[i-1].numero){
        i++;
    }
    if (x == pApont->reg[i-1].numero){
        printf("Registro ja esta presente!");
        *cresceu = FALSE;
        return;
    }
    if (x < pApont->reg[i-1].numero){
        i--;
    }
    Aux_Insere(x, pApont->vet[i], cresceu, retorno, pRetorno);
    if(!*cresceu){
        return;
    }
    if(pApont->n < 4){
        Insere_Dados_Pagina();
        *cresceu = FALSE;
        return;
    }
    pTemp = (Apontador)malloc(sizeof(Pagina));
    pTemp->n = 0;
    pTemp->vet[0] = NULL;
    if(i < 2+1){
        Insere_Dados_Pagina();
        pApont->n--;
        Insere_Dados_Pagina();
    }else{
        Insere_Dados_Pagina();
    }
    for(j = 2+1; j <= 4; j++){
        Insere_Dados_Pagina();
    }
    pApont->n = 2;
    pTemp->vet[0] = pApont->vet[2+1];
    *retorno = pApont->reg[2];
    *pRetorno = pTemp;
}

void Insere_Dados_Pagina(Apontador pApont, int x){
    int NenhumaPosicao;
    int k;
    k = pApont->n;
    NenhumaPosicao = (k > 0);
    while (NenhumaPosicao){
        if()
    }
}

#endif // TESTE_H_INCLUDED
