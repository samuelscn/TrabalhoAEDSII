#include <stdlib.h>
#include <stdio.h>
#include <gtk/gtk.h>
#include <ctype.h>
#include "arvoreB.h"

apontador aux(){
    Tipo_pag *arvore;
    reg teste;
    Inicializa(&arvore);
    teste.chave = 10;
    Insere(teste, &arvore);
    return arvore;
}

void enter_callback( GtkWidget *widget, GtkWidget *entry){
    Tipo_pag *ox;
    const gchar *entry_text;
    reg meu;
    int convert;

    entry_text = gtk_entry_get_text (GTK_ENTRY (entry));
    convert = atoi(entry_text);
    meu.chave = convert;
    ox = aux();
    Insere(meu, &ox);
    Imprime(ox);
}

void deletado( GtkWidget *widget, GtkWidget *entry){
    Tipo_pag *ox;
    const gchar *entry_text;
    int convert;

    entry_text = gtk_entry_get_text (GTK_ENTRY (entry));
    convert = atoi(entry_text);
    ox = aux();
    Retira(convert, &ox); //Nao funfa
    Imprime(ox);
}

void pesquisando( GtkWidget *widget, GtkWidget *entry){
    Tipo_pag *ox;
    const gchar *entry_text;
    reg meu;
    int convert;

    entry_text = gtk_entry_get_text (GTK_ENTRY (entry));
    convert = atoi(entry_text);
    meu.chave = convert;
    ox = aux();
    Pesquisa(meu, ox);
}

void print_msg(GtkWidget *widget, gpointer window) {
    GtkWidget *NewWindow;
    GtkWidget *vbox, *hbox;
    GtkWidget *entry;
    GtkWidget *button;
    gint tmp_pos;

    NewWindow = gtk_window_new (GTK_WINDOW_TOPLEVEL);
    gtk_widget_set_size_request (GTK_WIDGET (NewWindow), 400, 100);
    gtk_window_set_title (GTK_WINDOW (NewWindow), "Entre com o valor");
    g_signal_connect (NewWindow, "destroy",G_CALLBACK (gtk_main_quit), NULL);
    g_signal_connect_swapped (NewWindow, "delete-event", G_CALLBACK (gtk_widget_destroy),NewWindow);
    vbox = gtk_vbox_new (FALSE, 0);
    gtk_container_add (GTK_CONTAINER (NewWindow), vbox);
    gtk_widget_show (vbox);
    entry = gtk_entry_new ();
    gtk_entry_set_max_length (GTK_ENTRY (entry), 50);
    g_signal_connect (entry, "activate", G_CALLBACK (enter_callback), entry);
    gtk_entry_set_text (GTK_ENTRY (entry), "");
    gtk_editable_insert_text (GTK_EDITABLE (entry), "", -1, &tmp_pos);
    gtk_box_pack_start (GTK_BOX (vbox), entry, TRUE, TRUE, 0);
    gtk_widget_show (entry);
    hbox = gtk_hbox_new (FALSE, 0);
    gtk_container_add (GTK_CONTAINER (vbox), hbox);
    gtk_widget_show (hbox);
    button = gtk_button_new_from_stock (GTK_STOCK_CLOSE);
    g_signal_connect_swapped (button, "clicked", G_CALLBACK (gtk_widget_destroy),NewWindow);
    gtk_box_pack_start (GTK_BOX (vbox), button, TRUE, TRUE, 0);
    gtk_widget_set_can_default (button, TRUE);
    gtk_widget_grab_default (button);
    gtk_widget_show (button);
    gtk_widget_show (NewWindow);
    gtk_main();
    return ;
}

void retira_elemento(GtkWidget *widget, gpointer window) {
    GtkWidget *NewWindow;
    GtkWidget *vbox, *hbox;
    GtkWidget *entry;
    GtkWidget *button;
    gint tmp_pos;
    NewWindow = gtk_window_new (GTK_WINDOW_TOPLEVEL);
    gtk_widget_set_size_request (GTK_WIDGET (NewWindow), 400, 100);
    gtk_window_set_title (GTK_WINDOW (NewWindow), "Entre com o valor");
    g_signal_connect (NewWindow, "destroy",G_CALLBACK (gtk_main_quit), NULL);
    g_signal_connect_swapped (NewWindow, "delete-event", G_CALLBACK (gtk_widget_destroy), NewWindow);
    vbox = gtk_vbox_new (FALSE, 0);
    gtk_container_add (GTK_CONTAINER (NewWindow), vbox);
    gtk_widget_show (vbox);
    entry = gtk_entry_new ();
    gtk_entry_set_max_length (GTK_ENTRY (entry), 50);
    g_signal_connect (entry, "activate", G_CALLBACK (deletado),entry);
    gtk_entry_set_text (GTK_ENTRY (entry), "");
    gtk_editable_insert_text (GTK_EDITABLE (entry), "", -1, &tmp_pos);
    gtk_box_pack_start (GTK_BOX (vbox), entry, TRUE, TRUE, 0);
    gtk_widget_show (entry);
    hbox = gtk_hbox_new (FALSE, 0);
    gtk_container_add (GTK_CONTAINER (vbox), hbox);
    gtk_widget_show (hbox);
    button = gtk_button_new_from_stock (GTK_STOCK_CLOSE);
    g_signal_connect_swapped (button, "clicked", G_CALLBACK (gtk_widget_destroy),NewWindow);
    gtk_box_pack_start (GTK_BOX (vbox), button, TRUE, TRUE, 0);
    gtk_widget_set_can_default (button, TRUE);
    gtk_widget_grab_default (button);
    gtk_widget_show (button);
    gtk_widget_show (NewWindow);
    gtk_main();

    return ;
}

void pesquisa_elemento(GtkWidget *widget, gpointer window) {
    GtkWidget *NewWindow;
    GtkWidget *vbox, *hbox;
    GtkWidget *entry;
    GtkWidget *button;
    gint tmp_pos;

    NewWindow = gtk_window_new (GTK_WINDOW_TOPLEVEL);
    gtk_widget_set_size_request (GTK_WIDGET (NewWindow), 400, 100);
    gtk_window_set_title (GTK_WINDOW (NewWindow), "Entre com o valor");
    g_signal_connect (NewWindow, "destroy", G_CALLBACK (gtk_main_quit), NULL);
    g_signal_connect_swapped (NewWindow, "delete-event", G_CALLBACK (gtk_widget_destroy),NewWindow);
    vbox = gtk_vbox_new (FALSE, 0);
    gtk_container_add (GTK_CONTAINER (NewWindow), vbox);
    gtk_widget_show (vbox);

    entry = gtk_entry_new ();
    gtk_entry_set_max_length (GTK_ENTRY (entry), 50);
    g_signal_connect (entry, "activate", G_CALLBACK (pesquisando), entry);
    gtk_entry_set_text (GTK_ENTRY (entry), "");
    gtk_editable_insert_text (GTK_EDITABLE (entry), "", -1, &tmp_pos);
    gtk_box_pack_start (GTK_BOX (vbox), entry, TRUE, TRUE, 0);
    gtk_widget_show (entry);
    hbox = gtk_hbox_new (FALSE, 0);
    gtk_container_add (GTK_CONTAINER (vbox), hbox);
    gtk_widget_show (hbox);
    button = gtk_button_new_from_stock (GTK_STOCK_CLOSE);
    g_signal_connect_swapped (button, "clicked", G_CALLBACK (gtk_widget_destroy), NewWindow);
    gtk_box_pack_start (GTK_BOX (vbox), button, TRUE, TRUE, 0);
    gtk_widget_set_can_default (button, TRUE);
    gtk_widget_grab_default (button);
    gtk_widget_show (button);
    gtk_widget_show (NewWindow);
    gtk_main();

    return ;
}

int main( int argc, char *argv[]){

  GtkWidget *window;
  GtkWidget *box;
  GtkWidget *insercao;
  GtkWidget *retirada;
  GtkWidget *pesquisa;
  GtkWidget *fechar;
  GtkWidget *halign;

  gtk_init(&argc, &argv);
  window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);
  gtk_window_set_title(GTK_WINDOW(window), "Main");
  gtk_window_set_default_size(GTK_WINDOW(window), 230, 250);
  gtk_container_set_border_width(GTK_CONTAINER(window), 5);
  box = gtk_vbox_new(TRUE, 1);
  gtk_container_add(GTK_CONTAINER(window), box);
  insercao = gtk_button_new_with_mnemonic("Insercao");
  retirada = gtk_button_new_with_label("Retirada");
  pesquisa = gtk_button_new_with_label("Pesquisa");
  gtk_box_pack_start(GTK_BOX(box), insercao, TRUE, TRUE, 0);
  gtk_box_pack_start(GTK_BOX(box), retirada, TRUE, TRUE, 0);
  gtk_box_pack_start(GTK_BOX(box), pesquisa, TRUE, TRUE, 0);
  g_signal_connect(insercao, "clicked", G_CALLBACK(print_msg), NULL);
  halign = gtk_alignment_new(0, 0, 0, 0);
  gtk_container_add(GTK_CONTAINER(halign), insercao);
  gtk_container_add(GTK_CONTAINER(window), halign);
  g_signal_connect(retirada, "clicked", G_CALLBACK(retira_elemento), NULL);
  halign = gtk_alignment_new(0, 0, 0, 0);
  gtk_container_add(GTK_CONTAINER(halign), retirada);
  gtk_container_add(GTK_CONTAINER(window), halign);
  g_signal_connect(pesquisa, "clicked", G_CALLBACK(pesquisa_elemento), NULL);
  halign = gtk_alignment_new(0, 0, 0, 0);
  gtk_container_add(GTK_CONTAINER(halign), pesquisa);
  gtk_container_add(GTK_CONTAINER(window), halign);
  fechar = gtk_button_new_from_stock (GTK_STOCK_CLOSE);
  g_signal_connect_swapped (fechar, "clicked", G_CALLBACK (gtk_widget_destroy), window);
  gtk_box_pack_start (GTK_BOX (box), fechar, TRUE, TRUE, 0);
  gtk_widget_set_can_default (fechar, TRUE);
  gtk_widget_grab_default (fechar);
  gtk_widget_show (fechar);
  gtk_widget_show_all(window);
  g_signal_connect(G_OBJECT(window), "destroy", G_CALLBACK(gtk_main_quit), NULL);
  gtk_main();
  
/*/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////*/

  Tipo_pag *arvore;
  reg teste;
  FILE *arquivo;
  Inicializa(&arvore);
  if((arquivo = fopen("arquivo.txt", "r")) == NULL)
    {
        printf("Nao foi possivel ler o arquivo!");
        return 0;
    }
    else
    {
        while(fscanf(arquivo, "%d", teste.chave!= EOF){
            Insere(teste,&arvore);
        }

    }
fclose(arquivo);

  return 0;
}
