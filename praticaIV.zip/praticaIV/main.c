#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include "praticaIV.h"

int main()
{
    node* ptr, * head;
    int j, n, total = 0;
    int u;
    int c[15];
    char texto[24];
    node* a[12];
    int freq;
    Armazena_palavra h;
    n=9;
    Inicia_vPalavra(&h);
    Insere_palavra("para", &h);
    Insere_palavra("cada", &h);
    Insere_palavra("rosa", &h);
    Insere_palavra("rosa", &h);
    Insere_palavra("uma", &h);
    Insere_palavra("rosa", &h);
    Insere_palavra("e", &h);
    Insere_palavra("uma", &h);
    Insere_palavra("rosa", &h);
    OrdenaVET(&h);
    Imprime(&h);
    printf(  "Huffman Algorithm\n\n\n\n\n");
    //Imprime(&h);
    printf("\nEnter the no. of letter to be coded:");/*input the no. of letters*/
    //printf("ANTES DO FOR");
    //Imprime(&h);
    scanf("%d", &n);
        for (j = 0; j < n; j++){
            {
                strcpy(texto, h.Vet_palavra[j].p);
                freq=h.Vet_palavra[j].peso;
                //printf("%s", texto);
                //printf("%d", freq);
                a[j] = create(texto, freq);
            }
            while (n > 1)
            {
                        //sort(a, n);
                        u = h.Vet_palavra[0].peso + h.Vet_palavra[1].peso;
                        strcpy(texto,h.Vet_palavra[0].p);
                        strcat(texto,h.Vet_palavra[1].p);
                        ptr = create(texto, u);
                        ptr->right = a[1];
                        ptr->left = a[0];
                                    printf("\nkjh");
                        a[0] = ptr;
                        sright(a, n);
                        n--;
            }
            Assign_Code(a[0], c, 0);
            getch();
            Delete_Tree(a[0]);
    return 0;
}
}

