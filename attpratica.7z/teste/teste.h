#ifndef TESTE_H_INCLUDED
#define TESTE_H_INCLUDED

typedef struct{
    char p;
    int peso;
}Palavra;

typedef struct{
    Palavra Vet_palavra[20];
}Armazena_palavra;

void Inicia_vPalavra(Armazena_palavra *pPalavra){
    int i;

    for(i=0; i<20; i++){
        strcpy(pPalavra->Vet_palavra[i].p, NULL);
        pPalavra->Vet_palavra[i].peso = NULL;
    }
}

void Insere_palavra(char palavra, Armazena_palavra *pPalavra){
    int i;

    for(i=0; i<20; i++){
        if(strcmp(pPalavra->Vet_palavra[i].p, palavra) != 0){
            if(pPalavra->Vet_palavra[i].p == NULL){
                strcpy(pPalavra->Vet_palavra[i].p, palavra);
                pPalavra->Vet_palavra[i].peso = 1;
                break;
            }else{
                i++;
            }
        }else{
            pPalavra->Vet_palavra[i].peso = pPalavra->Vet_palavra[i].peso + 1;
            break;
        }
    }
}

void Ordena(Armazena_palavra *pPalavra){
    int i;

}

void Conta_nPalavras(Armazena_palavra){

}

#endif // TESTE_H_INCLUDED
