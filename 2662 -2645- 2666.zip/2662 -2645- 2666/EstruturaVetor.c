#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "EstruturaVetor.h"

/*Vinicius Simim 2645, Jonathan Lopes 2666, Samuel Silva 2662*/
/*Fun��es utilizadas para criar o vetor de caracteres e peso*/

void Inicia_vPalavra(Armazena_palavra *pPalavra){
    int i;
    char aux[24];

    for(i=0; i<8; i++){
        pPalavra->Vet_palavra[i].p = NULL;
        pPalavra->Vet_palavra[i].peso = NULL;
    }
}

void Insere_palavra(char *vai, Armazena_palavra *pPalavra){
    int i;

    for(i=0; i<8; i++){
        if(pPalavra->Vet_palavra[i].p == NULL){
            pPalavra->Vet_palavra[i].p = vai;
            pPalavra->Vet_palavra[i].peso = 1;
            break;
        }else{
            if(pPalavra->Vet_palavra[i].p == vai){
                pPalavra->Vet_palavra[i].peso = pPalavra->Vet_palavra[i].peso + 1;
                break;
            }
        }
    }
}

void Imprime(Armazena_palavra *pPalavra){
    int i;

    for(i = 0; i<8; i++){
        if(pPalavra->Vet_palavra[i].p == NULL){
            break;
        }else{
            printf("%c\n", pPalavra->Vet_palavra[i].p);
            printf("%d\n", pPalavra->Vet_palavra[i].peso);
            printf("\n");
        }
    }
}

void Ordena(Armazena_palavra *pPalavra){
    int k, j, aux;
    char palavra;

    for (k = 1; k < 8; k++) {
        for (j = 0; j < 8 - 1; j++) {
            if (pPalavra->Vet_palavra[j].peso > pPalavra->Vet_palavra[j+1].peso) {
                aux = pPalavra->Vet_palavra[j].peso;
                palavra = pPalavra->Vet_palavra[j].p;
                pPalavra->Vet_palavra[j].peso = pPalavra->Vet_palavra[j+1].peso;
                pPalavra->Vet_palavra[j].p = pPalavra->Vet_palavra[j+1].p;
                pPalavra->Vet_palavra[j+1].peso = aux;
                pPalavra->Vet_palavra[j+1].p = palavra;
            }
        }
    }
}

int PegaVetor(Armazena_palavra *pPalavra, int i){

    return pPalavra->Vet_palavra[i].p;
}

int PegaPeso(Armazena_palavra *pPalavra, int i){

    return pPalavra->Vet_palavra[i].peso;
}
