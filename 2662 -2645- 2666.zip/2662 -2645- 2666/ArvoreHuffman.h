#ifndef ARVOREHUFFMAN_H_INCLUDED
#define ARVOREHUFFMAN_H_INCLUDED

/*Vinicius Simim 2645, Jonathan Lopes 2666, Samuel Silva 2662*/
/*Estrutura arvore Huffman com Heap, feita utilizando como referencia
o codigo do site geeksforgeeks*/

typedef struct huffman_no *Heap;

typedef struct huffman_no{
    char palavra;
    int peso;
    Heap pEsq, pDir;
}Huffman_No;

typedef struct{
    int tamanho;
    int maximo;
    Heap *vetor;
}Huffman;

int CriaNo(char palavra, int peso);
int CriaH(int maximo);
int Tamanho_Um(Huffman *Mini);
void InserirNovoNoHeap(Huffman *pMini, Heap pMiniNo);
void CriaMiniHeap(Huffman *MiniHeap);
void mHeap(Huffman *Mini, int aux);
void HeapAux(Heap *a, Heap *b);
void printArr(int vet[], int n);
int Folha(Heap raiz);
int CriaDefinitivoMiniHeap(char palavra[], int peso[], int tamanho);
int IniciaArvore(char palavra[], int peso[], int tamanho);
int extractMin(Huffman *Mini);
void printCodes(Heap Raiz, int vet[], int cima);
void PrintaVetor(int vet[], int n);
void HuffmanCodes(char palavra[], int peso[], int tamanho);

#endif // ARVOREHUFFMAN_H_INCLUDED
