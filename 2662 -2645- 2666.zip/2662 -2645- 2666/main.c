#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArvoreHuffman.h"
#include "EstruturaVetor.h"

/*Vinicius Simim 2645, Jonathan Lopes 2666, Samuel Silva 2662*/
/*Utilizamos de um arquivo para salvar em um vetor contendo o caracter e o peso, apos
feito isso utilizamos da arvore de huffman para salvar os caracteres ordenados por peso
e assim transformalos em conjuntos binarios!*/

int main()
{
    Armazena_palavra h;
    Inicia_vPalavra(&h);
    FILE *arq;
    char armazena_char;
    char vetCaractere[8];
    int peso[8];
    int i;

    int size = sizeof(vetCaractere) / sizeof(vetCaractere[0]);

    arq = fopen("arquivo.txt", "r");
    if(arq == NULL){
        printf("Nao foi possivel abrir o arquivo!\n");
        return 0;
    }else{
        while(fscanf(arq, "%c\n", &armazena_char) != EOF){
            Insere_palavra(armazena_char, &h);
        }
    }
    Ordena(&h);

    for(i = 0; i<8; i++){
        vetCaractere[i] = PegaVetor(&h, i);
        peso[i] = PegaPeso(&h, i);
    }
    HuffmanCodes(vetCaractere, peso, size);
    printf("Arquivo comprimido com sucesso!");

    return 0;
}
