#ifndef ESTRUTURAVETOR_H_INCLUDED
#define ESTRUTURAVETOR_H_INCLUDED

/*Vinicius Simim 2645, Jonathan Lopes 2666, Samuel Silva 2662*/
/*Estrutura de dados feita para criar um vetor de caracteres e peso*/

typedef struct{
    char p;
    int peso;
}Palavra;

typedef struct{
    Palavra Vet_palavra[8];
}Armazena_palavra;

void Inicia_vPalavra(Armazena_palavra *pPalavra);
void Insere_palavra(char *vai, Armazena_palavra *pPalavra);
void Ordena(Armazena_palavra *pPalavra);
void Imprime(Armazena_palavra *pPalavra);
int PegaVetor(Armazena_palavra *pPalavra, int i);
int PegaPeso(Armazena_palavra *pPalavra, int i);

#endif // ESTRUTURAVETOR_H_INCLUDED
